﻿layout: post
title: "PowerShell 技能连载 - 键盘技巧"
date: 2013-11-13 00:00:00
description: PowerTip of the Day - Keyboard Trick
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
在 PowerShell ISE 4.0 控制台窗格中，按住 `CTRL` 键，然后按 `向上` 键，可以将光标从命令行中移到结果区域中。
<!--more-->
本文国际来源：[Keyboard Trick](http://powershell.com/cs/blogs/tips/archive/2013/11/13/keyboard-trick.aspx)
