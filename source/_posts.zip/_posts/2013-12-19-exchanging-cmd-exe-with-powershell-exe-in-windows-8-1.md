﻿layout: post
title: "PowerShell 技能连载 - 将 Windows 8.1 中的 CMD.EXE 替换为 POWERSHELL.EXE"
date: 2013-12-19 00:00:00
description: PowerTip of the Day - Exchanging CMD.EXE with POWERSHELL.EXE in Windows 8.1
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
Windows 8.1 仍然在它的一些上下文菜单中提供旧的 cmd.exe 命令行窗口。在 Windows 8.1 中，要将它由 cmd.exe 改为 powershell.exe，请右键单击任务栏，然后选择属性。

然后，单击“导航”标签页，然后选中第三个选项。

下一次，当您在 Windows 8.1 中按下 `WIN+X` 键时，迷你菜单上将显示“PowerShell”。

<!--more-->
本文国际来源：[Exchanging CMD.EXE with POWERSHELL.EXE in Windows 8.1](http://powershell.com/cs/blogs/tips/archive/2013/12/19/exchanging-cmd-exe-with-powershell-exe-in-windows-8-1.aspx)
