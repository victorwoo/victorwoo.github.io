﻿layout: post
title: "PowerShell 技能连载 - 在 PowerShell ISE 中创建干净的测试环境"
date: 2014-02-17 00:00:00
description: PowerTip of the Day - Use Fresh Testing Environment in PowerShell ISE
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
当您在 PowerShell ISE 编辑器中开发 PowerShell 脚本时，您需要在一个干净的环境中运行最终的测试，确保不会被之前运行时残留的变量或者函数干扰。

创建一个干净的测试环境的最简单方法是：选择文件菜单，然后选择“新建 PowerShell 选项卡”。这将为您带来一个新的标签页，并且该页代表一个全新的 PowerShell 宿主。完美的测试环境！

<!--more-->
本文国际来源：[Use Fresh Testing Environment in PowerShell ISE](http://powershell.com/cs/blogs/tips/archive/2014/02/17/use-fresh-testing-environment-in-powershell-ise.aspx)
