﻿layout: post
title: "JavaScript 最佳实践"
date: 2015-01-21 10:02:56
description: "JavaScript Best Practices"
categories:
- javascript
tags:
- javascript
- bestpractice
---
![](/img/2015-01-21-JavaScript-Best-Practices-001.jpg)

[45 Useful JavaScript Tips, Tricks and Best Practices - Modern Web](http://modernweb.com/2013/12/23/45-useful-javascript-tips-tricks-and-best-practices/)
