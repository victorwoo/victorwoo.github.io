﻿layout: post
title: "PowerShell 技能连载 - 访问终极 PowerShell 生存指南"
date: 2013-11-27 00:00:00
description: PowerTip of the Day - Visit the Ultimate PowerShell Survival Guide
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
您熟悉 PowerShell 生存指南吗？它是终极的 PowerShell 维基页面，包括视频、Module，和您很可能需要的关于 PowerShell 的一切资源。最棒的部分：它是一个开放式维基，所以如果您自己创建了一个 PowerShell 资源，希望让其他人知道它，那么您完全可以编辑 PowerShell 生存指南来让别人知道它。

http://social.technet.microsoft.com/wiki/contents/articles/183.windows-powershell-survival-guide.aspx

<!--more-->
本文国际来源：[Visit the Ultimate PowerShell Survival Guide](http://powershell.com/cs/blogs/tips/archive/2013/11/27/visit-the-ultimate-powershell-survival-guide.aspx)
