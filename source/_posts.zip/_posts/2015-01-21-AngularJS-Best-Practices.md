﻿layout: post
title: "AngularJS 最佳实践"
date: 2015-01-21 09:44:06
description: "AngularJS Best Practices"
categories: 
- angularjs
tags:
- angularjs
- javascript
- bestpractice
- guide
---
![](/img/2015-01-21-AngularJS-Best-Practices-001.png)
<!--more-->

# johnpapa/[angularjs-styleguide](https://github.com/johnpapa/angularjs-styleguide)

- Watch 419
- Star 5,141
- Fork 569

# mgechev/[angularjs-style-guide](https://github.com/mgechev/angularjs-style-guide)

- Watch 191
- Star 2,625
- Fork 313

中文版：
[README-zh-cn.md](https://github.com/mgechev/angularjs-style-guide/blob/master/README-zh-cn.md "README-zh-cn.md")

# turingou/[Angular-Best-Practices](https://github.com/turingou/Angular-Best-Practices)
本repo由支付宝前端开发工程师 @莫登（新浪微博@郭宇）维护，部分案例包括Angular在 支付宝某些系统上的使用经验

- Watch 7
- Star 21
- Fork 6

# [AngularJS移动开发中的坑汇总](http://blog.csdn.net/offbye/article/details/38490821)

- Watch 7
- Star 21
- Fork 6

# [AngularJS 最佳实践 – 尘埃落定](http://www.lovelucy.info/angularjs-best-practices.html)
