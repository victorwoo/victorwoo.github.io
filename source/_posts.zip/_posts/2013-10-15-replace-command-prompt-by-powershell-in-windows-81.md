﻿layout: post
title: "将 Windows 8.1 的命令提示符替换为 PowerShell"
date: 2013-10-15 00:00:00
description: Replace Command Prompt by PowerShell in Windows 8.1
categories: powershell
tags:
- powershell
- windows
---
在 Windows 8.1 中，增加了一个“将 WIN+X 菜单中将命令提示符替换为 Windows PowerShell”功能，您注意到了吗？

![](/img/2013-10-15-replace-command-prompt-by-powershell-in-windows-81-002.png)

打开这个选项的方法是：右键单击 Windows 任务栏，选择“属性”。在“导航”选项卡中，您可以找到这个功能。

![](/img/2013-10-15-replace-command-prompt-by-powershell-in-windows-81-001.png)
