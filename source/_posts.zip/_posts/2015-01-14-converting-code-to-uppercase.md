﻿layout: post
date: 2015-01-14 12:00:00
title: "PowerShell 技能连载 - 将代码转为大写"
description: PowerTip of the Day - Converting Code to Uppercase
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
_适用于 PowerShell 3.0 及以上版本_

在 PowerShell ISE 中要将 PowerShell 的代码转为全大写，请选中文本，并按下 `CTRL + SHIFT + U`。

To turn text to all lowercase letters, press CTRL+U.
要将文本转为全小写，请按 `CTRL+U`。

<!--more-->
本文国际来源：[Converting Code to Uppercase](http://powershell.com/cs/blogs/tips/archive/2015/01/14/converting-code-to-uppercase.aspx)
