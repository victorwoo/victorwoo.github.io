﻿layout: post
title: "如何简洁地汇报 bug"
date: 2014-07-11 00:00:00
description: Report Bug Compactly
categories: software-engineering
tags:
- geek
- bug
---
英文：

    Given input X I would expect output Y, but your app gives me Z instead. 

中文：

    我输入了 X，期望输出结果是 Y，而您的程序输出了 Z。
