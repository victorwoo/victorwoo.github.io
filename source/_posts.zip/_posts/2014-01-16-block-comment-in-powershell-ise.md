﻿layout: post
title: "PowerShell 技能连载 - 在 PowerShell ISE 中使用块注释"
date: 2014-01-16 00:00:00
description: PowerTip of the Day - Block Comment in PowerShell ISE
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
从 PowerShell 3.0 开始，您可以按住 `ALT` 键并选择一些内容，来获取一个矩形选区。

如果您尽可能地缩窄这个选区（您将只看到一条细细的蓝线），您可以方便地在选区之内增加或删除字符。只需要按下“`#`”键即可块注释它们，或者删除 # 号重新启用这段代码。

<!--more-->
本文国际来源：[Block Comment in PowerShell ISE](http://powershell.com/cs/blogs/tips/archive/2014/01/16/block-comment-in-powershell-ise.aspx)
