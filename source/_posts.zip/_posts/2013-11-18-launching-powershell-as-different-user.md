﻿layout: post
title: "PowerShell 技能连载 - 以不同用户运行 PowerShell"
date: 2013-11-18 00:00:00
description: PowerTip of the Day - Launching PowerShell as Different User
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
当您将 PowerShell 固定到任务栏后，您可以右键单击固定的 PowerShell 图标来打开一个跳转列表并且使用完整的 Administrator 特权来打开 PowerShell 或 ISE 编辑器。

您还可以按住 `SHIFT` 键并且右键单击跳转列表中的 PowerShell 图标。这将打开另一个快捷菜单，您可以在这里选择一个完全不同的凭据来运行 PowerShell。

并没有针对 ISE 编辑器的这个选项，但是当您以不同的凭据运行了 PowerShell 之后，您可以简单地键入命令“`ise`”来以相同的账户运行 ISE 编辑器。

<!--more-->
本文国际来源：[Launching PowerShell as Different User](http://powershell.com/cs/blogs/tips/archive/2013/11/18/launching-powershell-as-different-user.aspx)
