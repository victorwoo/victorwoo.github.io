﻿layout: post
date: 2014-09-09 11:00:00
title: "PowerShell 技能连载 - 重要的数学函数"
description: PowerTip of the Day - Important Math Functions
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
_适用于 PowerShell 不同版本_

以下是管理脚本中最重要的 4 个数学函数：

    [Math]::Floor(4.9)
    [Math]::Ceiling(3.2)
    [Math]::Max(3,8)
    [Math]::Min(3,8)

<!--more-->
本文国际来源：[Important Math Functions](http://powershell.com/cs/blogs/tips/archive/2014/09/09/important-math-functions.aspx)
