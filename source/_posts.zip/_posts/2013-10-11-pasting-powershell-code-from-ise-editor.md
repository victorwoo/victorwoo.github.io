﻿layout: post
title: "PowerShell 技能连载 - 从ISE编辑器中粘贴 PowerShell 代码"
date: 2013-10-11 00:00:00
description: PowerTip of the Day - Pasting PowerShell Code from ISE Editor
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
PowerShell ISE 编辑器的代码复制粘贴功能十分强大，例如将代码复制粘贴到 Microsoft Word 和其它文字处理器。由于 ISE 将剪贴板文字格式化为 RTF 格式，颜色代码将不会丢失。

然而，粘贴的时候字体往往太大或太小。

您可以在 ISE 编辑器中更改它。打开工具 > 选项，然后选择一个不同的字号。您在这儿选择的字号将用于粘贴的代码中。

当您更改完字号并关闭对话框之后，试着用 ISE 编辑器窗口右下角的滑块调整字体显示大小。这里的缩放级别只会影响 ISE 编辑器中的代码，并且不会影响粘贴的代码。

您也可以用鼠标滚轮来调整 ISE 编辑器中的显示字体大小。
<!--more-->

本文国际来源：[Pasting PowerShell Code from ISE Editor](http://powershell.com/cs/blogs/tips/archive/2013/10/11/pasting-powershell-code-from-ise-editor.aspx)
