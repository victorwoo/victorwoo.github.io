﻿layout: post
title: "PowerShell 技能连载 - 在 ISE 编辑器中使用块注释"
date: 2014-01-09 00:00:00
description: PowerTip of the Day - Using Block Comment in the ISE Editor
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
在 PowerShell 3.0 中，引入了一个小技巧，可以整块注释/取消注释某一段代码。

在 ISE 编辑器中，单击插入点（比如说一段代码的开头）。然后，按住 `SHIFT+ALT`，然后按下 `↓`键。

这时在 ISE 编辑器中将显示一条细细的绿线。当您高亮选中了这个块以后，在绿线消失前，按下 `#`（或任何您打算放在标记的行前的字符）。类似地，您也可以整块删除字符。

<!--more-->
本文国际来源：[Using Block Comment in the ISE Editor](http://powershell.com/cs/blogs/tips/archive/2014/01/09/using-block-comment-in-the-ise-editor.aspx)
