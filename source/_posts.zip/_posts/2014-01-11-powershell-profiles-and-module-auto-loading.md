﻿layout: post
title: "PowerShell 的配置和自动加载模块"
date: 2014-01-11 00:00:00
description: PowerShell Profiles and Module Auto Loading
categories: powershell
tags: powershell
---
以下是 PowerShell 配置（profile）的相关文章：
* [The Windows PowerShell Profile](http://technet.microsoft.com/en-us/library/ee692764.aspx)
* [Understanding the Six PowerShell Profiles](http://vmin.wordpress.com/2012/05/28/understanding-the-six-powershell-profiles-technet-blogs/)

以下是 PowerShell 自动加载模块的相关文章：
* [Loading Modules Automatically](http://powershell.com/cs/blogs/tips/archive/2013/11/21/loading-modules-automatically.aspx)
* [Improving Module Auto-loading](http://powershell.com/cs/blogs/tips/archive/2013/11/22/improving-module-auto-loading.aspx)
* [在所有用户登录时自动运行PowerShell脚本](http://www.pstips.net/run-powershell-scripts-when-each-user-login-on.html)
