﻿layout: post
date: 2015-02-11 12:00:00
title: "PowerShell 技能连载 - 将 PowerShell 工具增加到 Windows 8 启动屏幕"
description: PowerTip of the Day - Adding PowerShell Tools to Windows 8 Start Screen
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
_适用于 Windows 8/Windows 8.1_

您可能注意到了 Windows 8 启动屏幕默认没有 PowerShell ISE 之类的 PowerShell 工具。当您转到开始屏幕并且输入 "ISE" 时，搜不到任何结果。

要改变这种情况，请确保开始屏幕显示了“管理员工具”。在开始屏幕上，将鼠标移动到最右侧，直到出来一个菜单。然后，点击“设置”，然后点击“磁贴”。

现在打开“显示管理员工具”的滑块。

当您做完这步，Windows 8 启动屏幕将会显示 PowerShell 工具，并且当您键入 "ISE" 时内置的搜索工具将会显示 PowerShell ISE。

在搜索结果中右键单击 "Windows PowerShell ISE" 可以看到额外的选项，并且可以将编辑器钉在任务栏上。

<!--more-->
本文国际来源：[Adding PowerShell Tools to Windows 8 Start Screen](http://powershell.com/cs/blogs/tips/archive/2015/02/11/adding-powershell-tools-to-windows.aspx)
