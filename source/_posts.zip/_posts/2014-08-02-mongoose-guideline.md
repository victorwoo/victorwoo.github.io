﻿layout: post
date: 2014-08-02 17:51:38
title: mongoose 学习路线
description: mongoose guideline
categories: mongoose
tags:
- mongoose
- mongodb
- guideline
- link
- nosql
- database
---
[mongoose](http://mongoosejs.com/) 是 mongodb 的一个对象模型工具，可以工作于异步环境下。

![mongoose](/img/2014-08-02-mongoose-guideline-001.png)

# 入门文章

* [Mongoose学习参考文档——基础篇 - CNode](http://cnodejs.org/topic/504b4924e2b84515770103dd) 
* [Express + Mongoose 极简入门](http://freewind.me/blog/20120507/891.html)
* [nodejs学习7：express+mongoose - 前端博客](http://qianduanblog.com/post/nodejs-learning-7-express-mongoose.html)
* [<贴板> Mongoose - 让NodeJS更容易操作Mongodb数据库 - CSSer](http://www.csser.com/board/4f3f516e38a5ebc9780004fe)
