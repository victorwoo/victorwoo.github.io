﻿layout: post
title: "PowerShell 微软虚拟学院课程"
date: 2014-02-14 00:00:00
description: PowerShell MVA Lessons
categories: powershell
tags:
- powershell
- microsoft
- lesson
- video
- study
---
* [快速入门 PowerShell 3.0](http://pan.baidu.com/s/1hqKK1vA) - 入门篇。密码 `sja7`

* [快速入门 : PowerShell 3.0 高级工具和脚本](http://pan.baidu.com/s/1kTytM2F) - 提高篇。密码 `djqe`
