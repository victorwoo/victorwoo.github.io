﻿layout: post
title: "PowerShell 技能连载 - 智能感知显示变量的技巧"
date: 2014-04-22 00:00:00
description: PowerTip of the Day - IntelliSense Trick to Show Variables
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
在 PowerShell ISE 编辑器中，当您键入一个美元符号，将弹出一个智能感知菜单列出当前定义的所有变量。此时当您键入更多字符时，您不仅看见以这些字符开头的变量，而且还能看见在名字任意位置包含这些字符的变量。

要想只看到以您键入的字符开头的变量，请按下 `ESC` 键关闭智能感知菜单，然后按下 `CTRL`+`SPACE` 重新打开它。现在，它将只显示以您键入的字符开头的变量。

<!--more-->
本文国际来源：[IntelliSense Trick to Show Variables](http://powershell.com/cs/blogs/tips/archive/2014/04/22/intellisense-trick-to-show-variables.aspx)
