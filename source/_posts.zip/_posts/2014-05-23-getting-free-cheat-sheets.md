﻿layout: post
title: "PowerShell 技能连载 - 获取免费的速查表"
date: 2014-05-23 00:00:00
description: PowerTip of the Day - Getting Free Cheat Sheets
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
有两个很棒的 PowerShell 速查表版本。一个是由 powershellmagazine.com 创建的一系列速查表。它刚刚升级，现在覆盖了 PowerShell 4.0 并包括了一个期望状态配置（DSC）的速查表。您可以从 Microsoft 下载它：

[http://www.microsoft.com/en-us/download/details.aspx?id=42554](http://www.microsoft.com/en-us/download/details.aspx?id=42554)

另外一个是我们的每月技巧文摘，地址如下：

[http://powershell.com/cs/media/28/default.aspx](http://powershell.com/cs/media/28/default.aspx)

<!--more-->
本文国际来源：[Getting Free Cheat Sheets](http://powershell.com/cs/blogs/tips/archive/2014/05/23/getting-free-cheat-sheets.aspx)
