﻿layout: post
title: JavaScript 编码规范
date: 2015-01-20 14:08:22
description: JavaScript Style Guide
categories:
- javascript
tags:
- javascript
- style
- guide
---

1.  [Google's JavaScript style guide](http://google-styleguide.googlecode.com/svn/trunk/javascriptguide.xml)
2.  [Mozilla's JavaScript style guide](https://developer.mozilla.org/en-US/docs/Developer_Guide/Coding_Style)
3.  [GitHub's JavaScript style guide](https://github.com/styleguide/javascript)
4.  [Douglas Crockford's JavaScript style guide](http://javascript.crockford.com/code.html)
5.  [Airbnb JavaScript style guide](https://github.com/airbnb/javascript)
