﻿layout: post
date: 2014-11-05 12:00:00
title: "PowerShell 技能连载 - 显示 PowerShell 的命令行历史"
description: PowerTip of the Day - Display Command History in PowerShell Console
categories:
- powershell
- tip
tags:
- powershell
- tip
- powertip
- series
- translation
---
_适用于 PowerShell 所有版本_

在 PowerShell 控制台（非 PowerShell ISE）中，您只要按下 `F7` 键就可以列出刚才键入的命令列表。当然，如果还没有执行过任何命令，就不会显示任何内容。

按 `ALT+F7` 键将会清空命令行历史列表。

<!--more-->
本文国际来源：[Display Command History in PowerShell Console](http://powershell.com/cs/blogs/tips/archive/2014/11/05/display-command-history-in-powershell-console.aspx)
