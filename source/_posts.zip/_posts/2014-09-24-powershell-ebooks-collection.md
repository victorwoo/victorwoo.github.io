﻿layout: post
title: "PowerShell 电子书合集"
date: 2014-09-24 10:36:29
description: PowerShell Ebooks Collection
categories: powershell
tags:
- powershell
- ebook
---
搜集到的所有 PowerShell 电子书 [共享链接](https://link.getsync.com/#f=PowerShell&sz=0&t=2&s=QIRLDLFZIBPR6DHOJ4K6LGNMB2KDWXZUW5D4SATAGPIW4AY43IFA&i=CFAGNWFWQXY5KE2A5I3PIDSQCQOC6PCIS&v=2.0)
将来一旦有更新，就会自动同步、自动更新，再也不用为资料发愁了。如果您也有好料想一起分享，请在群里发个消息，我把读写权限给您。

最好在客户端的 `文件夹 / 偏好设定` 中的 `搜索 DHT 网络` 前打上勾，可以提高成功率 :)

![](/img/2014-09-24-powershell-ebooks-collection-001.png)
![](/img/2014-09-24-powershell-ebooks-collection-002.png)
