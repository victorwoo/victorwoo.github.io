﻿layout: post
title: "Microsoft Visual Studio 2013 Update 1 离线安装包下载"
date: 2014-01-22 00:00:00
description: Microsoft Visual Studio 2013 Update 1 Offline Package Download
categories: visualstudio
tags:
- visualstudio
- microsoft
- iso
- download
- release
- sp1
- update
---
下载信息
--------
[Visual Studio 2013 Update1 官网（微软下载中心）](http://www.microsoft.com/zh-cn/download/details.aspx?id=41650)

本次更新是适用于 Visual Studio 2013 的一系列新增功能和 Bug 修复中的最新更新。

- 出版日期：2014/1/17
- 版本：30110.00


[在线安装包](http://download.microsoft.com/download/8/2/6/826E264A-729E-414A-9E67-729923083310/VSU1/VS2013.1.exe)（1.1 MB）
---------------

- CRC  ：AD470B9E
- SHA-1：D3543BFE1F0DA6D7D63760C5C3A5A7166E2B6B42

[离线安装包（光盘镜像）](http://download.microsoft.com/download/8/2/6/826E264A-729E-414A-9E67-729923083310/VSU1/VS2013.1.iso)（245 MB）
---------------

- CRC  ：B9C46697
- SHA-1：51403CAF8E5E9799ACF1F3A0DA0E46390CD2FB16
