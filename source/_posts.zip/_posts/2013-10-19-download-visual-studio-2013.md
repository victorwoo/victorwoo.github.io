﻿layout: post
title: "下载 Visual Studio 2013"
date: 2013-10-19 00:00:00
description: Download Visual Studio 2013
categories: visualstudio
tags:
- visualstudio
- microsoft
- iso
- download
- release
---
下载信息
=======

英文版
-----

	Visual Studio Ultimate 2013 (x86) - DVD (English)
	语言：英语(美国)
	文件名：en_visual_studio_ultimate_2013_x86_dvd_3009107.iso
	发布日期(UTC)：2013-10-17 18:43:01文件大小：2.82 GB
	SHA1：79DBBA7B6EF12B1A4E715A7F20951EE66FBCDAB4


* [英文版下载地址（HTTP）](http://download.microsoft.com/download/C/F/B/CFBB5FF1-0B27-42E0-8141-E4D6DA0B8B13/VS2013_RTM_ULT_ENU.iso)
* [英文版下载地址（ED2K）](ed2k://|file|en_visual_studio_ultimate_2013_x86_dvd_3009107.iso|3024457728|88ABAD28F04D52A45F060BBC48B3DF8A|/)	
* [英文WEB在线安装版](http://www.microsoft.com/en-us/download/details.aspx?id=40778)

中文版
-----

	Visual Studio Ultimate 2013 (x86) - DVD (Chinese-Simplified)
	语言：中文(简体)
	文件名：cn_visual_studio_ultimate_2013_x86_dvd_3009109.iso
	发布日期(UTC)：2013-10-17 18:43:01文件大小：2.87 GB
	SHA1：07313542D36ED8BEEF18520AA4F15E33E32C7F77

* [中文版下载地址（HTTP）](http://download.microsoft.com/download/0/7/5/0755898A-ED1B-4E11-BC04-6B9B7D82B1E4/VS2013_RTM_ULT_CHS.iso)
* [中文版下载地址（ED2K）](ed2k://|file|cn_visual_studio_ultimate_2013_x86_dvd_3009109.iso|3077509120|14B49871392C76A6D640910A639CB8C2|/)
* [中文WEB在线安装版](http://www.microsoft.com/zh-CN/download/details.aspx?id=40778)

相关链接
=======
* [官方下载页面（中文）](http://www.microsoft.com/visualstudio/chs/downloads)
* [官方下载页面（英文）](http://www.microsoft.com/visualstudio/eng/downloads)
* [Announcing the Release of Visual Studio 2013 and Great Improvements to ASP.NET and Entity Framework](http://weblogs.asp.net/scottgu/archive/2013/10/17/announcing-the-release-of-visual-studio-2013-and-great-improvements-to-asp-net-and-entity-framework.aspx)
