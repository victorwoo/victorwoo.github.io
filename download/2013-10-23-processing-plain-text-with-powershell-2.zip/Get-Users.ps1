﻿$fileName = 'AllUsers.csv'

$currentLine = ''
gc $fileName | % -process {
        if ($_ -cmatch '^[a-zA-Z0-9/+=]{1,76}$') {
            # 如果符合 BASE64 特征，说明上一行未结束。
            $currentLine += $_
        } else {
            # 如果不符合 BASE64 特征，说明上一行是完整的。
            Write-Output $currentLine
            $currentLine = $_
        }
    } -end {
        $currentLine
    } | 
ConvertFrom-Csv