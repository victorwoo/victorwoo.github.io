﻿if (!(Test-Path dst)) {
    md dst | Out-Null
}

Get-ChildItem src\*.srt | ForEach-Object {
    $srcFile = $_
    Write-Output "Processing $($srcFile.Name)"
    $dstFile = (Join-Path 'dst' $srcFile.BaseName) + '.txt'
    Get-Content $srcFile | ForEach-Object {
        $line = $_
        if ($line -cmatch '\A\d+\z') { return }
        if ($line -cmatch '\d\d:\d\d:\d\d,\d\d\d --> \d\d:\d\d:\d\d,\d\d\d') { return }
        $line = $line -creplace '\s*\{\\.*?\}\s*', ''
        return $line
    } | Out-File $dstFile
}